import os

api_key = os.environ.get("WITH_AI_AGENTS_API_KEY", None)
platform = os.environ.get("WITH_AI_AGENTS_PLATFORM", None)
model_name = os.environ.get("WITH_AI_AGENTS_MODEL_NAME", None)
tavily_api_key = os.environ.get("WITH_AI_AGENTS_TAVILY_API_KEY", None)
